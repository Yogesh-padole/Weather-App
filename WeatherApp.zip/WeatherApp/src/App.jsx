import WeatherApp from "./weatherApp"

function App() {


  return (
    <>
     
      <WeatherApp/>

    </>
    
  )
}

export default App
